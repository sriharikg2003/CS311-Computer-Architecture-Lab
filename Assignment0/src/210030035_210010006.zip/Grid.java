public class Grid {
    int x;
    int y;
    boolean sensorWorking;
    boolean triggered;
    public Grid(int X, int Y) {
        x = X;
        y = Y;
        triggered = false;
        sensorWorking = false;
    }

    
}
