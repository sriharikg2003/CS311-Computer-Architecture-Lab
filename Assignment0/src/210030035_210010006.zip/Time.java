public class Time {
    int waqt;
    int caught = 0;
}
